# Sticker Mule Support Agent

A small AI customer-support agent built with Python and the OpenAI Responses API.

## What it demonstrates

- LLM-based agent workflow
- Custom function/tool calling
- Order-status lookup
- Product recommendation
- Structured tool arguments
- Multi-turn tool execution
- Basic error handling
- Separation between the model and business logic

## Architecture

Customer message
       |
       v
   AI Agent
       |
   +---+----------------+
   |                    |
   v                    v
Order Lookup       Product Recommendation
   |                    |
   +---------+----------+
             |
             v
        Agent Response

## Setup

Requires Python 3.10+.

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Set your OpenAI API key as an environment variable:

```bash
export OPENAI_API_KEY="your_api_key_here"
```

On Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="your_api_key_here"
```

3. Run:

```bash
python agent.py
```

## Example prompts

```text
Where is order SM1001?

I need something for branding my laptop. What do you recommend?

Can you check order SM1002?
```

## Important note

The order and product data in this portfolio project are demo data. A production implementation would replace these functions with authenticated calls to the company's order-management and product systems.

## Why I built it

This project demonstrates how an AI model can decide when to call application tools instead of relying only on generated text. The design keeps business data and actions in normal Python functions while the model handles natural-language interaction and tool selection.
