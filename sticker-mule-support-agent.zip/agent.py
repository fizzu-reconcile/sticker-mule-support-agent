import json
import os
from openai import OpenAI

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Demo data. In a real production system these would come from a database/API.
ORDERS = {
    "SM1001": {
        "status": "shipped",
        "product": "Die-cut stickers",
        "estimated_delivery": "2026-09-27",
    },
    "SM1002": {
        "status": "processing",
        "product": "Custom labels",
        "estimated_delivery": "2026-10-02",
    },
}

PRODUCTS = [
    {"name": "Die-cut stickers", "use_case": "logos, branding, laptops", "minimum": 10},
    {"name": "Vinyl lettering", "use_case": "windows, walls, signs", "minimum": 1},
    {"name": "Custom labels", "use_case": "packaging, bottles, products", "minimum": 25},
]


def lookup_order(order_id: str) -> dict:
    """Look up a demo order by ID."""
    order = ORDERS.get(order_id.upper())
    if not order:
        return {"found": False, "message": "Order not found. Ask the customer to verify the order ID."}
    return {"found": True, "order_id": order_id.upper(), **order}


def recommend_product(use_case: str) -> dict:
    """Recommend a product based on the customer's use case."""
    text = use_case.lower()
    matches = [
        product for product in PRODUCTS
        if any(word in text for word in product["use_case"].split(", "))
    ]
    if not matches:
        return {
            "matches": [],
            "message": "No exact demo match. Ask a clarifying question about what the customer wants to make."
        }
    return {"matches": matches}


TOOLS = [
    {
        "type": "function",
        "name": "lookup_order",
        "description": "Look up a customer's order status using the order ID.",
        "parameters": {
            "type": "object",
            "properties": {
                "order_id": {"type": "string", "description": "The customer's order ID, e.g. SM1001"}
            },
            "required": ["order_id"],
            "additionalProperties": False,
        },
        "strict": True,
    },
    {
        "type": "function",
        "name": "recommend_product",
        "description": "Recommend a sticker/product type based on what the customer wants to make.",
        "parameters": {
            "type": "object",
            "properties": {
                "use_case": {"type": "string", "description": "What the customer wants the product for"}
            },
            "required": ["use_case"],
            "additionalProperties": False,
        },
        "strict": True,
    },
]

SYSTEM_PROMPT = """
You are a professional customer-support AI agent for a custom printing and sticker company.

Your goals:
1. Answer customer questions clearly and politely.
2. Use tools when you need order information or a product recommendation.
3. Never invent an order status or product information.
4. If an order cannot be found, ask the customer to verify the order ID.
5. If you cannot solve an issue, explain what information a human support agent would need.
6. Keep responses concise and practical.
"""


def run_agent(user_message: str) -> str:
    response = client.responses.create(
        model="gpt-5.5",
        instructions=SYSTEM_PROMPT,
        input=user_message,
        tools=TOOLS,
    )

    # The model may request one or more tool calls.
    while True:
        tool_outputs = []

        for item in response.output:
            if item.type != "function_call":
                continue

            args = json.loads(item.arguments)

            if item.name == "lookup_order":
                result = lookup_order(**args)
            elif item.name == "recommend_product":
                result = recommend_product(**args)
            else:
                result = {"error": f"Unknown tool: {item.name}"}

            tool_outputs.append({
                "type": "function_call_output",
                "call_id": item.call_id,
                "output": json.dumps(result),
            })

        if not tool_outputs:
            return response.output_text

        response = client.responses.create(
            model="gpt-5.5",
            instructions=SYSTEM_PROMPT,
            previous_response_id=response.id,
            input=tool_outputs,
            tools=TOOLS,
        )


if __name__ == "__main__":
    print("Sticker Mule Support Agent")
    print("Type 'exit' to quit.\n")

    while True:
        user_message = input("Customer: ").strip()
        if user_message.lower() in {"exit", "quit"}:
            break
        if not user_message:
            continue

        try:
            print("Agent:", run_agent(user_message))
        except Exception as exc:
            print("Agent error:", exc)
